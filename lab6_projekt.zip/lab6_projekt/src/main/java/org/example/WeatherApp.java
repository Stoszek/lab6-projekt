package org.example;

import com.google.gson.Gson;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class WeatherApp extends JFrame {
    private JTextArea textArea;
    private JTextField latitudeField;
    private JTextField longitudeField;
    private JTextField startDateField;
    private JTextField endDateField;
    private JTextField cityField;
    private EntityManagerFactory emf;

    public WeatherApp() {
        emf = Persistence.createEntityManagerFactory("weatherPU");
        initUI();
    }

    private void initUI() {
        setTitle("Weather App");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        textArea = new JTextArea(20, 50);
        textArea.setFont(new Font("Arial", Font.PLAIN, 14));
        JScrollPane scrollPane = new JScrollPane(textArea);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 4;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        panel.add(scrollPane, gbc);

        JLabel latitudeLabel = new JLabel("Latitude:");
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.NONE;
        gbc.weightx = 0;
        gbc.weighty = 0;
        panel.add(latitudeLabel, gbc);

        latitudeField = new JTextField(10);
        gbc.gridx = 1;
        gbc.gridy = 1;
        panel.add(latitudeField, gbc);

        JLabel longitudeLabel = new JLabel("Longitude:");
        gbc.gridx = 2;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.WEST;
        panel.add(longitudeLabel, gbc);

        longitudeField = new JTextField(10);
        gbc.gridx = 3;
        gbc.gridy = 1;
        panel.add(longitudeField, gbc);

        JButton fetchButton = new JButton("Fetch Weather");
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 4;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        panel.add(fetchButton, gbc);
        fetchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                fetchWeatherData();
            }
        });

        JButton showAllButton = new JButton("Show All Weather Data");
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 4;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        panel.add(showAllButton, gbc);
        showAllButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                displayAllWeatherData();
            }
        });

        JLabel startDateLabel = new JLabel("Start Date:");
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.NONE;
        panel.add(startDateLabel, gbc);

        startDateField = new JTextField(10);
        gbc.gridx = 1;
        gbc.gridy = 4;
        gbc.gridwidth = 1;
        panel.add(startDateField, gbc);

        JLabel endDateLabel = new JLabel("End Date:");
        gbc.gridx = 2;
        gbc.gridy = 4;
        gbc.gridwidth = 1;
        panel.add(endDateLabel, gbc);

        endDateField = new JTextField(10);
        gbc.gridx = 3;
        gbc.gridy = 4;
        gbc.gridwidth = 1;
        panel.add(endDateField, gbc);

        JLabel cityLabel = new JLabel("City:");
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 1;
        panel.add(cityLabel, gbc);

        cityField = new JTextField(10);
        gbc.gridx = 1;
        gbc.gridy = 5;
        gbc.gridwidth = 3;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        panel.add(cityField, gbc);

        JButton filterButton = new JButton("Filter Weather Data");
        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 4;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        panel.add(filterButton, gbc);
        filterButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                displayFilteredWeatherData();
            }
        });

        add(panel);
        pack();
        setLocationRelativeTo(null);
    }

    private void fetchWeatherData() {
        try {
            float latitude = Float.parseFloat(latitudeField.getText());
            float longitude = Float.parseFloat(longitudeField.getText());
            String apiUrl = String.format("https://api.openweathermap.org/data/2.5/weather?lat=%f&lon=%f&appid=184f86296734df65eb5199f43ab1d193", latitude, longitude);

            URL url = new URL(apiUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            InputStreamReader reader = new InputStreamReader(conn.getInputStream());
            WeatherResponse response = new Gson().fromJson(reader, WeatherResponse.class);

            WeatherBaseInfo weatherData = new WeatherBaseInfo();
            weatherData.setCityName(response.name);
            weatherData.setCountry(response.sys.country);
            weatherData.setLatitude(response.coord.lat);
            weatherData.setLongitude(response.coord.lon);
            weatherData.setTimezone(response.timezone);
            weatherData.setTemperature(response.main.temp);
            weatherData.setPressure(response.main.pressure);
            weatherData.setHumidity(response.main.humidity);
            weatherData.setWindSpeed(response.wind.speed);
            weatherData.setWindDirection(response.wind.deg);
            weatherData.setWeatherCondition(response.weather.get(0).main);
            weatherData.setDateAdded(LocalDateTime.now());

            EntityManager em = emf.createEntityManager();
            em.getTransaction().begin();
            em.persist(weatherData);
            em.getTransaction().commit();
            em.close();

            updateWeatherInfo(latitude, longitude);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void displayAllWeatherData() {
        textArea.setText("");
        EntityManager em = emf.createEntityManager();
        List<WeatherBaseInfo> weatherDataList = em.createQuery("SELECT w FROM WeatherBaseInfo w", WeatherBaseInfo.class).getResultList();
        for (WeatherBaseInfo weatherData : weatherDataList) {
            textArea.append(String.format("City: %s\nCountry: %s\nLatitude: %f\nLongitude: %f\nTimezone: %d\nTemperature: %fK\nPressure: %d\nHumidity: %d%%\nWind Speed: %f m/s\nWind Direction: %d°\nWeather Condition: %s\nDate Added: %s\n\n",
                    weatherData.getCityName(), weatherData.getCountry(), weatherData.getLatitude(), weatherData.getLongitude(), weatherData.getTimezone(), weatherData.getTemperature(), weatherData.getPressure(), weatherData.getHumidity(), weatherData.getWindSpeed(), weatherData.getWindDirection(), weatherData.getWeatherCondition(), weatherData.getDateAdded()));
        }
        em.close();
    }

    private void displayFilteredWeatherData() {
        textArea.setText("");
        boolean isStartDateValid = !startDateField.getText().isEmpty();
        boolean isEndDateValid = !endDateField.getText().isEmpty();
        boolean isCityFilterActive = !cityField.getText().isEmpty();

        LocalDateTime startDate = null;
        LocalDateTime endDate = null;

        if (isStartDateValid) {
            startDate = parseDate(startDateField.getText());
        }

        if (isEndDateValid) {
            endDate = parseDate(endDateField.getText()).plusDays(1).minusSeconds(1);  // Ustawienie końca dnia
        }

        EntityManager em = emf.createEntityManager();
        String queryStr = "SELECT w FROM WeatherBaseInfo w WHERE 1=1";

        if (isStartDateValid && isEndDateValid) {
            queryStr += " AND w.dateAdded BETWEEN :startDate AND :endDate";
        }

        if (isCityFilterActive) {
            queryStr += " AND LOWER(w.cityName) LIKE :cityFilter";
        }

        var query = em.createQuery(queryStr, WeatherBaseInfo.class);

        if (isStartDateValid && isEndDateValid) {
            query.setParameter("startDate", startDate);
            query.setParameter("endDate", endDate);
        }

        if (isCityFilterActive) {
            query.setParameter("cityFilter", "%" + cityField.getText().toLowerCase() + "%");
        }

        List<WeatherBaseInfo> weatherDataList = query.getResultList();
        for (WeatherBaseInfo weatherData : weatherDataList) {
            textArea.append(String.format("City: %s\nCountry: %s\nLatitude: %f\nLongitude: %f\nTimezone: %d\nTemperature: %fK\nPressure: %d\nHumidity: %d%%\nWind Speed: %f m/s\nWind Direction: %d°\nWeather Condition: %s\nDate Added: %s\n\n",
                    weatherData.getCityName(), weatherData.getCountry(), weatherData.getLatitude(), weatherData.getLongitude(), weatherData.getTimezone(), weatherData.getTemperature(), weatherData.getPressure(), weatherData.getHumidity(), weatherData.getWindSpeed(), weatherData.getWindDirection(), weatherData.getWeatherCondition(), weatherData.getDateAdded()));
        }
        em.close();
    }

    private LocalDateTime parseDate(String dateStr) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        LocalDate localDate = LocalDate.parse(dateStr, formatter);
        return localDate.atStartOfDay();
    }

    private void updateWeatherInfo(float latitude, float longitude) {
        textArea.setText("");
        EntityManager em = emf.createEntityManager();
        WeatherBaseInfo weatherData = em.createQuery("SELECT w FROM WeatherBaseInfo w WHERE w.latitude = :latitude AND w.longitude = :longitude", WeatherBaseInfo.class)
                .setParameter("latitude", latitude)
                .setParameter("longitude", longitude)
                .getSingleResult();

        if (weatherData != null) {
            textArea.append(String.format("City: %s\nCountry: %s\nLatitude: %f\nLongitude: %f\nTimezone: %d\nTemperature: %fK\nPressure: %d\nHumidity: %d%%\nWind Speed: %f m/s\nWind Direction: %d°\nWeather Condition: %s\nDate Added: %s\n\n",
                    weatherData.getCityName(), weatherData.getCountry(), weatherData.getLatitude(), weatherData.getLongitude(), weatherData.getTimezone(), weatherData.getTemperature(), weatherData.getPressure(), weatherData.getHumidity(), weatherData.getWindSpeed(), weatherData.getWindDirection(), weatherData.getWeatherCondition(), weatherData.getDateAdded()));
        }
        em.close();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            WeatherApp app = new WeatherApp();
            app.setVisible(true);
        });
    }
}
